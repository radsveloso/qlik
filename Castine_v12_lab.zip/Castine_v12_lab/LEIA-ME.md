# Teste local do Castine v12 no Qlik Sense Desktop

Objetivo: fazer o primeiro reload real do `Castine_Python_Replica_v12.qvs` fora do Santander, com arquivos de teste sintéticos (nenhum dado do cliente), e conferir que o resultado é idêntico ao que o `Castine.py` gerou para os mesmos arquivos.

O script entra **sem nenhuma alteração**: as pastas `Fldr_SDrive` e `Fldr_QlikShare` deste pacote fazem o papel das duas conexões que existem no servidor.

## O que tem no pacote

| Item | Para que serve |
|---|---|
| `Castine_Python_Replica_v12.qvs` | o script, igual ao que vai para o Santander |
| `Fldr_SDrive\` | raiz da conexão `Fldr_SDrive` (XML Bloomberg, Repo, ajustes, Tiara, matriz de split, e os payouts do Python usados na comparação) |
| `Fldr_QlikShare\` | raiz da conexão `Fldr_QlikShare` (`SCRIPT\Config_QS.txt`) |
| `referencia\` | o que o `Castine.py` gerou: payouts de 30/01 e 02/02, alertas e log |

## Passo a passo

1. **Windows.** Windows 10/11 de 64 bits. Em VM no Mac (UTM ou VMware Fusion com Windows 11 ARM) o Desktop roda emulando x64; a Qlik exige CPU com AVX, então pode não abrir. Um PC Windows comum não tem esse risco.
2. **Qlik Sense Desktop.** Baixe com a sua conta Qlik e instale. O arquivo `Qlik_Sense_Desktop.unlock`, segundo relatos da Qlik Community, vai em `Documentos\Qlik\Sense\trial` (crie a pasta `trial` se não existir). Confira a data de validade dele.
3. **Pacote.** Copie este zip para dentro do Windows (não rode de pasta compartilhada com o Mac) e extraia em `C:\castine_lab`.
4. **App.** Abra o Desktop, crie um app (ex.: `Castine v12 lab`) e abra o **Editor de carga de dados**.
5. **Conexões.** Em *Criar nova conexão > Pasta*:
   - caminho `C:\castine_lab\Fldr_SDrive`, nome exatamente **`Fldr_SDrive`**
   - caminho `C:\castine_lab\Fldr_QlikShare`, nome exatamente **`Fldr_QlikShare`**
   Se o nome ficar com sufixo (ex.: `Fldr_SDrive (usuario)`), renomeie para o nome exato.
6. **Script.** Apague o conteúdo da seção do editor, cole o arquivo `.qvs` inteiro e clique em **Carregar dados**. As linhas `///$tab` viram comentários numa seção só; isso não muda nada.

## Cenário 1 (padrão): `vDateLimitToken = '260130'`

O que deve aparecer no log:

- `[CASTINE] Payout date: 20260130`
- `[CASTINE] XML files selected (highest version of each): 2`
- `[CASTINE] rows_after_versioning: 39` e `rows_after_remove_cancels: 38 (removed=1)`
- `[COMPARE] rows in a different position: 0`
- `[COMPARE] RESULT: this reload is IDENTICAL to the Python export - every row, all 23 columns;`
- `Character set check of ... utf8 = 1` para o arquivo de ajustes (ele tem acentos em UTF-8) e `utf8 = 0` para os outros

Tabela `Qlik`: 51 linhas. Arquivo gerado: `Fldr_SDrive\UAT\Qlikview\Sales\Data\castine\QLIK_V12_PPT_DailyExportOfPayout_20260130.csv`, que deve ter o mesmo conteúdo de `referencia\PPT_DailyExportOfPayout_20260130.csv` (o do Qlik tem BOM UTF-8, e pode haver aspas diferentes).

Alertas: no fim do log aparecem 10 linhas `[COMPARE] alert <arquivo>: MATCH`, uma para cada arquivo de alerta. A tabela `COMPARE_ALERTS` mostra o mesmo. O script compara cada `QLIK_V12_<alerta>.csv` gravado em `Fldr_SDrive\UAT\Qlikview\Sales\Data\castine\` com o arquivo do Python de mesmo nome em `...\castine\alerts\`, linha a linha, cabeçalho incluído. Se der `DIFFERENT`, a linha do log diz qual é a primeira linha diferente: abra os dois arquivos e me mande essa linha dos dois lados.

## Cenário 2: `vDateLimitToken = ''` (aba 01_Config)

- `Payout date: 20260202`, `XML files selected: 3`, `rows_after_versioning: 40`, `rows_after_remove_cancels: 39`
- `RESULT: ... IDENTICAL ...`, tabela `Qlik` com 41 linhas.
- Não há Repo nem ajustes para 02/02: os avisos de arquivo não encontrado são esperados.
- Alertas: antes de rodar, troque o conteúdo de `Fldr_SDrive\UAT\Qlikview\Sales\Data\castine\alerts\` pelo de `referencia\alerts_20260202\`. Os arquivos de alerta do Python não têm data no nome; a pasta vem com os de 30/01.

## Se não der IDENTICAL ou der erro

Me mande:

- a mensagem de erro (print) e a linha do script onde parou;
- o log do reload: normalmente em `Documentos\Qlik\Sense\Log`, arquivo com o nome do app;
- se o reload terminou: as tabelas `COMPARE_SUMMARY`, `COMPARE_FULL_ROW` (filtre `Full Row Status` diferente de `MATCH`) e `AUDIT_XML_FILES`.

Avisos esperados no log, que não são erro:

- `XML files ignored (no numeric version at the end of the name): 1` (é o `f392fd1.ext.26x`, de propósito).

Anote o número da linha `ExtendedFields layout in use: N`: ela mostra qual dos 4 layouts o motor deu aos campos Sec Type do XML de teste. É a primeira prova real de como o XmlSimple monta essa tabela. Se em vez dela aparecer `ExtendedFields was not read from any file`, me avise, porque aí Sec Type e Sec Type Description saem vazios e a comparação acusa diferença. Os arquivos reais podem ainda usar outro layout, e isso só o reload no Santander confirma.

## O que este teste prova e o que não prova

- **Prova:** que o motor Qlik aceita cada comando do script (sintaxe, funções, formatos `XmlSimple`, `ooxml`, `txt`, `fix`, `STORE`) e que, nesses arquivos, o resultado é o mesmo do Python.
- **Não prova:** a estrutura dos XML reais. Os de teste imitam o layout que o script de produção lê, mas os `ExtendedFields` reais nunca foram lidos por nenhum script Qlik. Também não prova a velocidade com um ano inteiro de arquivos.
